#include "Accelerometer.h"

const float Accelerometer::STANDARD_GRAVITY = 9.80665f;
